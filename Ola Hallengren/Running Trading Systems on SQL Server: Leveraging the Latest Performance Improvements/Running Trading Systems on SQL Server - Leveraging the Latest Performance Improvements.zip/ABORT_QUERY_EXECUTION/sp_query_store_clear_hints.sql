
EXECUTE sys.sp_query_store_clear_hints @query_id = 22
GO
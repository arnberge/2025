
SELECT name, compatibility_level
FROM sys.databases
WHERE name = 'WideWorldImporters'
USE [WideWorldImporters]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Sales].[OrdersGet]

@CustomerID INT

AS

SET NOCOUNT ON

SELECT *
FROM Sales.Orders
WHERE CustomerID = @CustomerID OR @CustomerID IS NULL
GO



USE WideWorldImporters
GO

EXECUTE [Sales].[OrdersGet] @CustomerID = NULL
GO

EXECUTE [Sales].[OrdersGet] @CustomerID = 1
GO

EXECUTE [Sales].[OrdersGet] @CustomerID = NULL
GO
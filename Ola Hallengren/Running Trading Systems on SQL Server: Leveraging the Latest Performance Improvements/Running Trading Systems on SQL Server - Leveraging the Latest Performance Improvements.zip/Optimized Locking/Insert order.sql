SET STATISTICS TIME ON

-- Insert a single order
INSERT INTO dbo.Orders (OrderDate, CustomerID)
SELECT '2025-01-11', 1 AS OrderDate